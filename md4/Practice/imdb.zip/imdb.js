var data = {
  "page": 1,
  "total_results": 350869,
  "total_pages": 17544,
  "results": [
    {
      "vote_count": 900,
      "id": 337167,
      "video": false,
      "vote_average": 6.2,
      "title": "Fifty Shades Freed",
      "popularity": 525.701922,
      "poster_path": "/jjPJ4s3DWZZvI4vw8Xfi4Vqa1Q8.jpg",
      "original_language": "en",
      "original_title": "Fifty Shades Freed",
      "genre_ids": [
        18,
        10749
      ],
      "backdrop_path": "/9ywA15OAiwjSTvg3cBs9B7kOCBF.jpg",
      "adult": false,
      "overview": "Believing they have left behind shadowy figures from their past, newlyweds Christian and Ana fully embrace an inextricable connection and shared life of luxury. But just as she steps into her role as Mrs. Grey and he relaxes into an unfamiliar stability, new threats could jeopardize their happy ending before it even begins.",
      "release_date": "2018-02-07"
    },
    {
      "vote_count": 6540,
      "id": 269149,
      "video": false,
      "vote_average": 7.7,
      "title": "Zootopia",
      "popularity": 380.23527,
      "poster_path": "/sM33SANp9z6rXW8Itn7NnG1GOEs.jpg",
      "original_language": "en",
      "original_title": "Zootopia",
      "genre_ids": [
        16,
        12,
        10751,
        35
      ],
      "backdrop_path": "/mhdeE1yShHTaDbJVdWyTlzFvNkr.jpg",
      "adult": false,
      "overview": "Determined to prove herself, Officer Judy Hopps, the first bunny on Zootopia's police force, jumps at the chance to crack her first case - even if it means partnering with scam-artist fox Nick Wilde to solve the mystery.",
      "release_date": "2016-02-11"
    },
    {
      "vote_count": 2950,
      "id": 284054,
      "video": false,
      "vote_average": 7.4,
      "title": "Black Panther",
      "popularity": 284.314356,
      "poster_path": "/uxzzxijgPIY7slzFvMotPv8wjKA.jpg",
      "original_language": "en",
      "original_title": "Black Panther",
      "genre_ids": [
        28,
        12,
        14,
        878
      ],
      "backdrop_path": "/b6ZJZHUdMEFECvGiDpJjlfUWela.jpg",
      "adult": false,
      "overview": "After the events of Captain America: Civil War, King T'Challa returns home to the reclusive, technologically advanced African nation of Wakanda to serve as his country's new leader. However, T'Challa soon finds that he is challenged for the throne from factions within his own country. When two foes conspire to destroy Wakanda, the hero known as Black Panther must team up with C.I.A. agent Everett K. Ross and members of the Dora Milaje, Wakandan special forces, to prevent Wakanda from being dragged into a world war.",
      "release_date": "2018-02-13"
    },
    {
      "vote_count": 2556,
      "id": 399055,
      "video": false,
      "vote_average": 7.4,
      "title": "The Shape of Water",
      "popularity": 283.73228,
      "poster_path": "/k4FwHlMhuRR5BISY2Gm2QZHlH5Q.jpg",
      "original_language": "en",
      "original_title": "The Shape of Water",
      "genre_ids": [
        18,
        14,
        10749
      ],
      "backdrop_path": "/rgyhSn3mINvkuy9iswZK0VLqQO3.jpg",
      "adult": false,
      "overview": "An other-worldly story, set against the backdrop of Cold War era America circa 1962, where a mute janitor working at a lab falls in love with an amphibious man being held captive there and devises a plan to help him escape.",
      "release_date": "2017-12-01"
    },
    {
      "vote_count": 3097,
      "id": 354912,
      "video": false,
      "vote_average": 7.8,
      "title": "Coco",
      "popularity": 244.333189,
      "poster_path": "/eKi8dIrr8voobbaGzDpe8w0PVbC.jpg",
      "original_language": "en",
      "original_title": "Coco",
      "genre_ids": [
        12,
        16,
        35,
        10751
      ],
      "backdrop_path": "/askg3SMvhqEl4OL52YuvdtY40Yb.jpg",
      "adult": false,
      "overview": "Despite his family’s baffling generations-old ban on music, Miguel dreams of becoming an accomplished musician like his idol, Ernesto de la Cruz. Desperate to prove his talent, Miguel finds himself in the stunning and colorful Land of the Dead following a mysterious chain of events. Along the way, he meets charming trickster Hector, and together, they set off on an extraordinary journey to unlock the real story behind Miguel's family history.",
      "release_date": "2017-10-27"
    },
    {
      "vote_count": 4288,
      "id": 181808,
      "video": false,
      "vote_average": 7.2,
      "title": "Star Wars: The Last Jedi",
      "popularity": 212.812982,
      "poster_path": "/kOVEVeg59E0wsnXmF9nrh6OmWII.jpg",
      "original_language": "en",
      "original_title": "Star Wars: The Last Jedi",
      "genre_ids": [
        28,
        14,
        12
      ],
      "backdrop_path": "/c4Dw37VZjBmObmJw9bmt8IDwMZH.jpg",
      "adult": false,
      "overview": "Rey develops her newly discovered abilities with the guidance of Luke Skywalker, who is unsettled by the strength of her powers. Meanwhile, the Resistance prepares to do battle with the First Order.",
      "release_date": "2017-12-13"
    },
    {
      "vote_count": 4891,
      "id": 284053,
      "video": false,
      "vote_average": 7.4,
      "title": "Thor: Ragnarok",
      "popularity": 193.308157,
      "poster_path": "/rzRwTcFvttcN1ZpX2xv4j3tSdJu.jpg",
      "original_language": "en",
      "original_title": "Thor: Ragnarok",
      "genre_ids": [
        28,
        12,
        14
      ],
      "backdrop_path": "/kaIfm5ryEOwYg8mLbq8HkPuM1Fo.jpg",
      "adult": false,
      "overview": "Thor is imprisoned on the other side of the universe and finds himself in a race against time to get back to Asgard to stop Ragnarok, the prophecy of destruction to his homeworld and the end of Asgardian civilization, at the hands of an all-powerful new threat, the ruthless Hela.",
      "release_date": "2017-10-25"
    },
    {
      "vote_count": 3554,
      "id": 141052,
      "video": false,
      "vote_average": 6.4,
      "title": "Justice League",
      "popularity": 179.670185,
      "poster_path": "/eifGNCSDuxJeS1loAXil5bIGgvC.jpg",
      "original_language": "en",
      "original_title": "Justice League",
      "genre_ids": [
        28,
        12,
        14,
        878
      ],
      "backdrop_path": "/o5T8rZxoWSBMYwjsUFUqTt6uMQB.jpg",
      "adult": false,
      "overview": "Fuelled by his restored faith in humanity and inspired by Superman's selfless act, Bruce Wayne and Diana Prince assemble a team of metahumans consisting of Barry Allen, Arthur Curry and Victor Stone to face the catastrophic threat of Steppenwolf and the Parademons who are on the hunt for three Mother Boxes on Earth.",
      "release_date": "2017-11-15"
    },
    {
      "vote_count": 2719,
      "id": 353486,
      "video": false,
      "vote_average": 6.5,
      "title": "Jumanji: Welcome to the Jungle",
      "popularity": 175.170116,
      "poster_path": "/bXrZ5iHBEjH7WMidbUDQ0U2xbmr.jpg",
      "original_language": "en",
      "original_title": "Jumanji: Welcome to the Jungle",
      "genre_ids": [
        28,
        12,
        35,
        10751
      ],
      "backdrop_path": "/rz3TAyd5kmiJmozp3GUbYeB5Kep.jpg",
      "adult": false,
      "overview": "The tables are turned as four teenagers are sucked into Jumanji's world - pitted against rhinos, black mambas and an endless variety of jungle traps and puzzles. To survive, they'll play as characters from the game.",
      "release_date": "2017-12-09"
    },
    {
      "vote_count": 7331,
      "id": 198663,
      "video": false,
      "vote_average": 7,
      "title": "The Maze Runner",
      "popularity": 134.216233,
      "poster_path": "/coss7RgL0NH6g4fC2s5atvf3dFO.jpg",
      "original_language": "en",
      "original_title": "The Maze Runner",
      "genre_ids": [
        28,
        9648,
        878,
        53
      ],
      "backdrop_path": "/lkOZcsXcOLZYeJ2YxJd3vSldvU4.jpg",
      "adult": false,
      "overview": "Set in a post-apocalyptic world, young Thomas is deposited in a community of boys after his memory is erased, soon learning they're all trapped in a maze that will require him to join forces with fellow “runners” for a shot at escape.",
      "release_date": "2014-09-10"
    },
    {
      "vote_count": 7611,
      "id": 321612,
      "video": false,
      "vote_average": 6.8,
      "title": "Beauty and the Beast",
      "popularity": 127.431772,
      "poster_path": "/tWqifoYuwLETmmasnGHO7xBjEtt.jpg",
      "original_language": "en",
      "original_title": "Beauty and the Beast",
      "genre_ids": [
        10751,
        14,
        10749
      ],
      "backdrop_path": "/6aUWe0GSl69wMTSWWexsorMIvwU.jpg",
      "adult": false,
      "overview": "A live-action adaptation of Disney's version of the classic tale of a cursed prince and a beautiful young woman who helps him break the spell.",
      "release_date": "2017-03-16"
    },
    {
      "vote_count": 339,
      "id": 401981,
      "video": false,
      "vote_average": 6.4,
      "title": "Red Sparrow",
      "popularity": 109.230078,
      "poster_path": "/vLCogyfQGxVLDC1gqUdNAIkc29L.jpg",
      "original_language": "en",
      "original_title": "Red Sparrow",
      "genre_ids": [
        9648,
        53
      ],
      "backdrop_path": "/sGzuQYSTwJvLBc2PnuSVLHhuFeh.jpg",
      "adult": false,
      "overview": "Prima ballerina Dominika Egorova faces a bleak and uncertain future after she suffers an injury that ends her career. She soon turns to Sparrow School, a secret intelligence service that trains exceptional young people to use their minds and bodies as weapons. Egorova emerges as the most dangerous Sparrow after completing the sadistic training process. As she comes to terms with her new abilities, Dominika meets a CIA agent who tries to convince her that he is the only person she can trust.",
      "release_date": "2018-03-01"
    },
    {
      "vote_count": 487,
      "id": 460793,
      "video": false,
      "vote_average": 5.9,
      "title": "Olaf's Frozen Adventure",
      "popularity": 99.60495,
      "poster_path": "/As8WTtxXs9e3cBit3ztTf7zoRmm.jpg",
      "original_language": "en",
      "original_title": "Olaf's Frozen Adventure",
      "genre_ids": [
        12,
        16,
        35,
        10751,
        14,
        10402
      ],
      "backdrop_path": "/9K4QqQZg4TVXcxBGDiVY4Aey3Rn.jpg",
      "adult": false,
      "overview": "Olaf is on a mission to harness the best holiday traditions for Anna, Elsa, and Kristoff.",
      "release_date": "2017-10-27"
    },
    {
      "vote_count": 3685,
      "id": 335984,
      "video": false,
      "vote_average": 7.3,
      "title": "Blade Runner 2049",
      "popularity": 97.598273,
      "poster_path": "/gajva2L0rPYkEWjzgFlBXCAVBE5.jpg",
      "original_language": "en",
      "original_title": "Blade Runner 2049",
      "genre_ids": [
        9648,
        878,
        53
      ],
      "backdrop_path": "/mVr0UiqyltcfqxbAUcLl9zWL8ah.jpg",
      "adult": false,
      "overview": "Thirty years after the events of the first film, a new blade runner, LAPD Officer K, unearths a long-buried secret that has the potential to plunge what's left of society into chaos. K's discovery leads him on a quest to find Rick Deckard, a former LAPD blade runner who has been missing for 30 years.",
      "release_date": "2017-10-04"
    },
    {
      "vote_count": 264,
      "id": 347882,
      "video": false,
      "vote_average": 5.2,
      "title": "Sleight",
      "popularity": 94.705164,
      "poster_path": "/wridRvGxDqGldhzAIh3IcZhHT5F.jpg",
      "original_language": "en",
      "original_title": "Sleight",
      "genre_ids": [
        18,
        53,
        28,
        878
      ],
      "backdrop_path": "/2SEgJ0mHJ7TSdVDbkGU061tR33K.jpg",
      "adult": false,
      "overview": "A young street magician is left to take care of his little sister after his mother's passing and turns to drug dealing in the Los Angeles party scene to keep a roof over their heads. When he gets into trouble with his supplier, his sister is kidnapped and he is forced to rely on both his sleight of hand and brilliant mind to save her.",
      "release_date": "2017-04-28"
    },
    {
      "vote_count": 2,
      "id": 499772,
      "video": false,
      "vote_average": 5.5,
      "title": "Meet Me In St. Gallen",
      "popularity": 94.505754,
      "poster_path": "/uGntNjUx6YAzbVy7RDgxWnWsdet.jpg",
      "original_language": "tl",
      "original_title": "Meet Me In St. Gallen",
      "genre_ids": [
        18,
        10749
      ],
      "backdrop_path": "/4QrbczSQGZQA7BG9xMhccQI7LHm.jpg",
      "adult": false,
      "overview": "The story of Jesse and Celeste who meets at an unexpected time in their lives. They then realize their names are the same as the characters in the popular break-up romantic comedy, Celeste and Jesse Forever.",
      "release_date": "2018-02-07"
    },
    {
      "vote_count": 22,
      "id": 394823,
      "video": false,
      "vote_average": 4.8,
      "title": "Robby and Toby's Fantastic Voyager",
      "popularity": 93.826229,
      "poster_path": "/ssCEE0bfj5gawzwZeGfqrGQtU3f.jpg",
      "original_language": "de",
      "original_title": "Robbi, Tobbi und das Fliewatüüt",
      "genre_ids": [
        12,
        10751
      ],
      "backdrop_path": "/gZF2EfM8ov834pCzRpt1xt01SUy.jpg",
      "adult": false,
      "overview": "One day, robot Robby enters into a life of the most creative little boy, Toby. Robby had been separated from his robot parents when his spaceship crashed. Toby decides to offer his help and the two of them become friends.",
      "release_date": "2016-12-01"
    },
    {
      "vote_count": 2288,
      "id": 392044,
      "video": false,
      "vote_average": 6.7,
      "title": "Murder on the Orient Express",
      "popularity": 88.74754,
      "poster_path": "/iBlfxlw8qwtUS0R8YjIU7JtM6LM.jpg",
      "original_language": "en",
      "original_title": "Murder on the Orient Express",
      "genre_ids": [
        80,
        18,
        9648
      ],
      "backdrop_path": "/2J283YNxKhxAqHeVegUJ5mzLfGb.jpg",
      "adult": false,
      "overview": "Genius Belgian detective Hercule Poirot investigates the murder of an American tycoon aboard the Orient Express train.",
      "release_date": "2017-11-03"
    },
    {
      "vote_count": 86,
      "id": 338970,
      "video": false,
      "vote_average": 6.2,
      "title": "Tomb Raider",
      "popularity": 88.636162,
      "poster_path": "/ePyN2nX9t8SOl70eRW47Q29zUFO.jpg",
      "original_language": "en",
      "original_title": "Tomb Raider",
      "genre_ids": [
        28,
        12,
        14
      ],
      "backdrop_path": "/bLJTjfbZ1c5zSNiAvGYs1Uc82ir.jpg",
      "adult": false,
      "overview": "Lara Croft, the fiercely independent daughter of a missing adventurer, must push herself beyond her limits when she finds herself on the island where her father disappeared.",
      "release_date": "2018-03-14"
    },
    {
      "vote_count": 1941,
      "id": 396422,
      "video": false,
      "vote_average": 6.4,
      "title": "Annabelle: Creation",
      "popularity": 86.528757,
      "poster_path": "/tb86j8jVCVsdZnzf8I6cIi65IeM.jpg",
      "original_language": "en",
      "original_title": "Annabelle: Creation",
      "genre_ids": [
        27,
        9648,
        53
      ],
      "backdrop_path": "/3L5gfIKt2RK9vnCiLgWTAzkhQWC.jpg",
      "adult": false,
      "overview": "Several years after the tragic death of their little girl, a dollmaker and his wife welcome a nun and several girls from a shuttered orphanage into their home, soon becoming the target of the dollmaker's possessed creation, Annabelle.",
      "release_date": "2017-08-03"
    }
  ]
};

console.log(data);
console.log(document.getElementById('movie_image').innerHTML);

var index = 0;
load(index);
function clickit(button) {
	if (button.id === "right") {
		index = index + 1;
	} else {
		index = index - 1;
	}

	if (index === 0) {
		document.getElementById('left').disabled = true;
	} else if (index === data.results.length - 1) {
		document.getElementById('right').disabled = true;
	} else {
		document.getElementById('left').disabled = false;
		document.getElementById('right').disabled = false;
	}
	load(index);
};

function load(val) {
	document.getElementById('movie_image').innerHTML = '<img class = "img-responsive" src = "https://image.tmdb.org/t/p/w500' + data.results[val].poster_path + '" alt = "title">';
	document.getElementById('movie_rating').innerHTML = data.results[val].vote_average;
	document.getElementById('movie_title').innerHTML = data.results[val].title;
	document.getElementById('movie_date').innerHTML = data.results[val].release_date;
	document.getElementById('movie_review').innerHTML = data.results[val].overview;
	document.getElementById('movie_info').innerHTML = '<a href = "https://www.google.co.in/search?q=' + data.results[val].title + '">More info link </a>';
}